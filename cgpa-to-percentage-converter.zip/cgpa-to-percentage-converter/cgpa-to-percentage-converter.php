<?php
/*
Plugin Name: CGPA to Percentage Converter
Description: A simple plugin to convert CGPA to percentage.
Version: 2.0
Author: Fakhra
*/

function cgpa_to_percentage_converter_shortcode() {
  ob_start(); ?>
  <style>
    /* Add your CSS styles here */

    .card {
        background-color: #092F54;
        border-radius: 8px;
        color:#fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        padding: 20px;
        margin: 20px;
        text-align: center;
           
    }
.card h2{color:white;}
    .input-group {
      margin-bottom: 15px;
    }

    label {
      display: block;
      color: #fff;
    }

    input[type="number"],
    select {
      border:2px solid #092F54;
      border-radius: 4px;
      padding: 8px;
      width: 200px;
      margin: 10px;
    }

    button {
     background-color: #c63001;
      color: #fff;
      border: none;
      border-radius: 4px;
      padding: 10px 20px;
      cursor: pointer;
      width:200px;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #092F54;
        color:#fff;
        border: 2px solid #c63001;
    }

  @media screen and (max-width: 600px) {
    .card {
        width: 90%;
      margin: 0 auto;

    }

    input[type="number"],
    select,
    button {
      padding: 15px;
     font-size: 18px;

    }
  </style>

  <div class="card">
    <h2>CGPA to Percentage Converter</h2>
    <div class="input-group">
      <label for="gradePoints">Choose your grade points:</label>
      <select id="gradePoints">
        <option value="10">10</option>
        <option value="5">5</option>
        <option value="4">4</option>
      </select>
    </div>
    <div class="input-group">
      <label for="cgpa">Enter your CGPA:</label>
      <input type="number" step="1.00" id="cgpa">
    </div>
    <button id="convertButton">Convert</button>
 
<p id="result" style="display: none; background-color: #c63001; margin:10px; padding: 10px; border: 3px solid #c63001; border-radius: 4px; color: #fff;">Your Percentage is: <span id="percentage"></span></p>
  </div>

  <script>
    // Add your JavaScript code here
    document.addEventListener('DOMContentLoaded', function() {
      const gradePointsDropdown = document.getElementById('gradePoints');
      const cgpaInput = document.getElementById('cgpa');
      const convertButton = document.getElementById('convertButton');
    //  const resultDiv = document.getElementById('result');

      convertButton.addEventListener('click', function() {
        const gradePoints = parseFloat(gradePointsDropdown.value);
        const cgpa = parseFloat(cgpaInput.value);
        const percentage = (cgpa / gradePoints) * 100;


        document.getElementById("percentage").textContent = percentage.toFixed(2);
            document.getElementById("result").style.display = "block";
      });
    });
  </script>
  <?php
  return ob_get_clean();
}
add_shortcode('cgpa_to_percentage_converter', 'cgpa_to_percentage_converter_shortcode');